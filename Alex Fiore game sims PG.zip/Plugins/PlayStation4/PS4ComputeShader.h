#pragma once
#ifdef _ORBIS
namespace NCL {
	namespace PS4 {
		class PS4ComputeShader
		{
		public:
			PS4ComputeShader();
			~PS4ComputeShader();
		};
	}
}
#endif
