#ifdef _ORBIS
#include "PS4AudioSource.h"

using namespace NCL::PS4;
PS4AudioSource::PS4AudioSource(SceAudio3dObjectId id)
{
	uiObjectId = id;
}


PS4AudioSource::~PS4AudioSource()
{

}

void PS4AudioSource::Update() {

}
#endif