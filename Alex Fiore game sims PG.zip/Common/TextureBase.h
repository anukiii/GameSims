#pragma once

namespace NCL {
	namespace Rendering {
		class TextureBase
		{
		public:
			virtual ~TextureBase();
		protected:
			TextureBase();

		};
	}
}

